var log = new Log();
log.info("Initializing sample Jaggery app");