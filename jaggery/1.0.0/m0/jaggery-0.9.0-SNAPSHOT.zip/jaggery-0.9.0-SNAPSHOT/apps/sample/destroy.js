var log = new Log();
log.info("Stopping sample Jaggery app");