var resources = function (page, meta) {
    return {
        js: ['codemirror.js', 'simple-hint.js', 'javascript-hint.js', 'xml.js', 'javascript.js', 'css.js', 'htmlmixed.js', 'htmlembedded.js', 'jaggery-hint-api.js', 'jaggery.js', 'google-code-prettify/prettify.js', 'tryit.jag', 'util.js', 'tryit.js'],
        css: ['codemirror.css', 'simple-hint.css', 'tomorrow.css', 'ambiance.css'],
        code: []
    };
};
