var resources = function (page, meta) {
    return {
        js: ['google-code-prettify/prettify.js', 'quickstart.js'],
        css: ['tomorrow.css'],
        code: []
    };
};


