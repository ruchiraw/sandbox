$(function() {
	prettyPrint();
	$('a[data-toggle=tooltip]').tooltip();
	
})