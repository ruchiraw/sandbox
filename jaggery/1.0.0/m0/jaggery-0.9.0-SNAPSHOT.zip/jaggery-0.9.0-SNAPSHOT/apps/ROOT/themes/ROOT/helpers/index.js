var resources = function (page, meta) {
    return {
        js: ['google-code-prettify/prettify.js', 'documentation.js'],
        css: ['tomorrow-night-eighties.css'],
        code: []
    };
};

