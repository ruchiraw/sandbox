$(function() {
	prettyPrint();
})