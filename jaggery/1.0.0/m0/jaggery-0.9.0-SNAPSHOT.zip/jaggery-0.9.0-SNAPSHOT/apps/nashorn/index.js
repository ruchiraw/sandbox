

application.serve(function (req, res) {
    //print('hello ruchira');
    //throw new Error("foo");
});

module.exports.a = 10;

exports.b = function() {
    print('b');
};