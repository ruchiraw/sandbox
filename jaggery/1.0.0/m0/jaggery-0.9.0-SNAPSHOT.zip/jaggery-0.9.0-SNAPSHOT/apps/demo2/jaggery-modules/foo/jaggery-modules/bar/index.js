exports.greet = function(name) {
    return 'hello ' + name + ' : by bar(2.0.0)';
};